package cryptoproject.keccak.algorithm;

public class KeccakException extends IllegalArgumentException {

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

    public KeccakException(String m) {
	
	super(m);
	
    }
    
}
