Pokretanje

U konzoli se pozicionirate na direktorij u kojem se nalazi CryptographyInJava.jar

Zatim upišete java -jar CryptographyInJava.jar i pritisnete enter.