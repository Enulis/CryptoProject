package crypt;

public enum Algorithm {
	AES,
	DES
}
