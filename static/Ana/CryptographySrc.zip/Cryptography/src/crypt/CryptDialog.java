package crypt;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.filechooser.FileNameExtensionFilter;

public class CryptDialog extends JDialog {

	private static final long serialVersionUID = 743414514464338326L;
	private final JPanel contentPanel = new JPanel();
	private JTextField textFieldUnosPoruke1;
	private JButton btnOk1;
	private JTextField textFieldRezultat2;
	private JTextField textFieldUnosPoruke3;
	private JTextField textFieldRezultat4;
	private JButton btnEcb1;
	private JButton btnCbc1;
	private JButton btnKriptiraj1;
	private JButton btnOdaberi11;
	private JButton btnOdaberi12;
	private JButton btnCbc2;
	private JButton btnEcb2;
	private JButton btnOdaberi21;
	private JButton btnOdaberi22;
	private JButton btnKriptiraj2;
	private JButton btnOk2;
	private JButton btnOdaberi23;
	private JButton btnCbc3;
	private JButton btnEcb3;
	private JButton btnCbc4;
	private JButton btnEcb4;
	private JButton btnOdaberi41;
	private JButton btnOdaberi42;
	private JButton btnOdaberi43;
	private JButton btnDekriptiraj4;
	private JButton btnOdaberi31;
	private JButton btnOdaberi32;
	private JButton btnOk3;
	private JButton btnDekriptiraj3;
	private JButton btnOk4;
	private JTextArea textAreaRezultat1;
	private JTextArea textAreaRezultat3;
	
	public static String mode;
	public static String datotekaTekst;
	public static String datotekaKljuc;
	public static String datotekaIv;
	
	

	public static void main(String[] args) {
		try {
			CryptDialog dialog = new CryptDialog();
			dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
			dialog.setVisible(true);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Create the dialog.
	 */
	public CryptDialog() {
		
		setBounds(100, 100, 415, 400);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(new BorderLayout(0, 0));
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		contentPanel.add(tabbedPane, BorderLayout.CENTER);
		
		JPanel pnlOne = new JPanel();
		tabbedPane.addTab("Kriptiranje poruke", null, pnlOne, null);
		JLabel lblOdabirNacina1 = new JLabel("Odabir načina kriptiranja");
		btnCbc1 = new JButton("CBC");
		btnEcb1 = new JButton("ECB");
		JLabel lblUnosPoruke1 = new JLabel("Unos poruke");
		textFieldUnosPoruke1 = new JTextField();
		textFieldUnosPoruke1.setColumns(10);
		btnKriptiraj1 = new JButton("Kriptiraj");
		JPanel pnlRezultat1 = new JPanel();
		pnlRezultat1.setBorder(new TitledBorder(null, "Rezultat", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		btnOk1 = new JButton("OK");
		JLabel lblOdaberiDatKljuc1 = new JLabel("Odaberi datoteku s ključem");
		JLabel lblOdaberiDatIV1 = new JLabel("Odaberi datoteku s IV");
		btnOdaberi11 = new JButton("Odaberi");
		btnOdaberi12 = new JButton("Odaberi");
		
		GroupLayout gl_pnlOne = new GroupLayout(pnlOne);
		gl_pnlOne.setHorizontalGroup(
			gl_pnlOne.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_pnlOne.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_pnlOne.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_pnlOne.createSequentialGroup()
							.addComponent(lblOdabirNacina1)
							.addPreferredGap(ComponentPlacement.RELATED, 64, Short.MAX_VALUE)
							.addComponent(btnEcb1)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(btnCbc1))
						.addGroup(gl_pnlOne.createSequentialGroup()
							.addComponent(lblUnosPoruke1)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(textFieldUnosPoruke1, GroupLayout.DEFAULT_SIZE, 266, Short.MAX_VALUE))
						.addComponent(btnOk1, Alignment.TRAILING)
						.addGroup(gl_pnlOne.createParallelGroup(Alignment.TRAILING, false)
							.addGroup(gl_pnlOne.createSequentialGroup()
								.addGroup(gl_pnlOne.createParallelGroup(Alignment.LEADING)
									.addComponent(btnKriptiraj1)
									.addComponent(lblOdaberiDatIV1, GroupLayout.PREFERRED_SIZE, 195, GroupLayout.PREFERRED_SIZE))
								.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(btnOdaberi12, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE))
							.addGroup(Alignment.LEADING, gl_pnlOne.createSequentialGroup()
								.addComponent(lblOdaberiDatKljuc1, GroupLayout.PREFERRED_SIZE, 195, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(btnOdaberi11, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE))
							.addComponent(pnlRezultat1, Alignment.LEADING, GroupLayout.PREFERRED_SIZE, 359, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap())
		);
		gl_pnlOne.setVerticalGroup(
			gl_pnlOne.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_pnlOne.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_pnlOne.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_pnlOne.createParallelGroup(Alignment.BASELINE)
							.addComponent(btnCbc1)
							.addComponent(btnEcb1))
						.addComponent(lblOdabirNacina1))
					.addGap(18)
					.addGroup(gl_pnlOne.createParallelGroup(Alignment.LEADING)
						.addComponent(lblUnosPoruke1)
						.addComponent(textFieldUnosPoruke1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_pnlOne.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_pnlOne.createSequentialGroup()
							.addComponent(lblOdaberiDatKljuc1)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(lblOdaberiDatIV1)
							.addPreferredGap(ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
							.addComponent(btnKriptiraj1))
						.addGroup(gl_pnlOne.createSequentialGroup()
							.addComponent(btnOdaberi11)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(btnOdaberi12)))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(pnlRezultat1, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(btnOk1)
					.addContainerGap())
		);
		
		textAreaRezultat1 = new JTextArea();
		textAreaRezultat1.setLineWrap(true);
		GroupLayout gl_pnlRezultat1 = new GroupLayout(pnlRezultat1);
		gl_pnlRezultat1.setHorizontalGroup(
			gl_pnlRezultat1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_pnlRezultat1.createSequentialGroup()
					.addContainerGap()
					.addComponent(textAreaRezultat1, GroupLayout.PREFERRED_SIZE, 331, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		gl_pnlRezultat1.setVerticalGroup(
			gl_pnlRezultat1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_pnlRezultat1.createSequentialGroup()
					.addComponent(textAreaRezultat1, GroupLayout.PREFERRED_SIZE, 44, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		pnlRezultat1.setLayout(gl_pnlRezultat1);
		pnlOne.setLayout(gl_pnlOne);
		
		JPanel pnlTwo = new JPanel();
		tabbedPane.addTab("Kriptiranje datoteke", null, pnlTwo, null);
		
		JLabel lblOdabirNacina2 = new JLabel("Odabir načina kriptiranja");
		btnCbc2 = new JButton("CBC");
		btnEcb2 = new JButton("ECB");		
		JLabel lblOdaberiDat2 = new JLabel("Odaberi datoteku za kriptiranje");
		btnOdaberi21 = new JButton("Odaberi");
		JLabel lblOdaberiDatKljuc2 = new JLabel("Odaberi datoteku s ključem");
		btnOdaberi22 = new JButton("Odaberi");		
		btnKriptiraj2 = new JButton("Kriptiraj");		
		JPanel pnlRezultat2 = new JPanel();
		pnlRezultat2.setBorder(new TitledBorder(null, "Rezultat", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		textFieldRezultat2 = new JTextField();
		textFieldRezultat2.setEditable(false);
		textFieldRezultat2.setColumns(10);
		
		GroupLayout gl_pnlRezultat2 = new GroupLayout(pnlRezultat2);
		gl_pnlRezultat2.setHorizontalGroup(
			gl_pnlRezultat2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_pnlRezultat2.createSequentialGroup()
					.addContainerGap()
					.addComponent(textFieldRezultat2, GroupLayout.DEFAULT_SIZE, 369, Short.MAX_VALUE)
					.addContainerGap())
		);
		gl_pnlRezultat2.setVerticalGroup(
			gl_pnlRezultat2.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_pnlRezultat2.createSequentialGroup()
					.addContainerGap()
					.addComponent(textFieldRezultat2, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(20, Short.MAX_VALUE))
		);
		pnlRezultat2.setLayout(gl_pnlRezultat2);
		
		btnOk2 = new JButton("OK");		
		JLabel lblOdaberiDatIV2 = new JLabel("Odaberi datoteku s IV");
		btnOdaberi23 = new JButton("Odaberi");
		
		
		GroupLayout gl_pnlTwo = new GroupLayout(pnlTwo);
		gl_pnlTwo.setHorizontalGroup(
			gl_pnlTwo.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_pnlTwo.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_pnlTwo.createParallelGroup(Alignment.LEADING)
						.addGroup(Alignment.TRAILING, gl_pnlTwo.createSequentialGroup()
							.addComponent(lblOdabirNacina2, GroupLayout.PREFERRED_SIZE, 177, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 58, Short.MAX_VALUE)
							.addComponent(btnEcb2, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(btnCbc2, GroupLayout.PREFERRED_SIZE, 61, GroupLayout.PREFERRED_SIZE))
						.addGroup(Alignment.TRAILING, gl_pnlTwo.createSequentialGroup()
							.addComponent(lblOdaberiDat2, GroupLayout.PREFERRED_SIZE, 225, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 58, Short.MAX_VALUE)
							.addComponent(btnOdaberi21, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE))
						.addGroup(Alignment.TRAILING, gl_pnlTwo.createSequentialGroup()
							.addComponent(lblOdaberiDatKljuc2, GroupLayout.PREFERRED_SIZE, 195, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 88, Short.MAX_VALUE)
							.addComponent(btnOdaberi22, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE))
						.addComponent(btnOk2, Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 54, GroupLayout.PREFERRED_SIZE)
						.addComponent(pnlRezultat2, GroupLayout.PREFERRED_SIZE, 362, GroupLayout.PREFERRED_SIZE)
						.addGroup(gl_pnlTwo.createSequentialGroup()
							.addGroup(gl_pnlTwo.createParallelGroup(Alignment.LEADING)
								.addComponent(btnKriptiraj2, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE)
								.addComponent(lblOdaberiDatIV2, GroupLayout.PREFERRED_SIZE, 195, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(ComponentPlacement.RELATED, 88, Short.MAX_VALUE)
							.addComponent(btnOdaberi23, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE)))
					.addContainerGap())
		);
		gl_pnlTwo.setVerticalGroup(
			gl_pnlTwo.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_pnlTwo.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_pnlTwo.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_pnlTwo.createParallelGroup(Alignment.BASELINE)
							.addComponent(btnCbc2)
							.addComponent(btnEcb2))
						.addComponent(lblOdabirNacina2))
					.addGap(18)
					.addGroup(gl_pnlTwo.createParallelGroup(Alignment.LEADING)
						.addComponent(btnOdaberi21)
						.addComponent(lblOdaberiDat2))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_pnlTwo.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnOdaberi22)
						.addComponent(lblOdaberiDatKljuc2))
					.addGroup(gl_pnlTwo.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_pnlTwo.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
							.addComponent(lblOdaberiDatIV2)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(btnKriptiraj2)
							.addPreferredGap(ComponentPlacement.UNRELATED))
						.addGroup(gl_pnlTwo.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(btnOdaberi23)
							.addPreferredGap(ComponentPlacement.RELATED)))
					.addComponent(pnlRezultat2, GroupLayout.PREFERRED_SIZE, 73, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(btnOk2)
					.addContainerGap())
		);
		pnlTwo.setLayout(gl_pnlTwo);
		
		JPanel pnlThree = new JPanel();
		tabbedPane.addTab("Dekriptiranje poruke", null, pnlThree, null);		
		JLabel lblOdabirNacina3 = new JLabel("Odabir načina dekriptiranja");		
		btnCbc3 = new JButton("CBC");		
		btnEcb3 = new JButton("ECB");		
		JLabel lblUnosPoruke3 = new JLabel("Unos poruke");		
		textFieldUnosPoruke3 = new JTextField();
		textFieldUnosPoruke3.setColumns(10);		
		btnDekriptiraj3 = new JButton("Dekriptiraj");	
		JPanel pnlRezultat3 = new JPanel();		
		pnlRezultat3.setBorder(new TitledBorder(null, "Rezultat", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		textAreaRezultat3 = new JTextArea();
		textAreaRezultat3.setWrapStyleWord(true);
		textAreaRezultat3.setLineWrap(true);
		GroupLayout gl_pnlRezultat3 = new GroupLayout(pnlRezultat3);
		gl_pnlRezultat3.setHorizontalGroup(
			gl_pnlRezultat3.createParallelGroup(Alignment.LEADING)
				.addGap(0, 359, Short.MAX_VALUE)
				.addGroup(gl_pnlRezultat3.createSequentialGroup()
					.addContainerGap()
					.addComponent(textAreaRezultat3, GroupLayout.PREFERRED_SIZE, 331, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		gl_pnlRezultat3.setVerticalGroup(
			gl_pnlRezultat3.createParallelGroup(Alignment.LEADING)
				.addGap(0, 78, Short.MAX_VALUE)
				.addGroup(gl_pnlRezultat3.createSequentialGroup()
					.addComponent(textAreaRezultat3, GroupLayout.PREFERRED_SIZE, 44, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		pnlRezultat3.setLayout(gl_pnlRezultat3);
		
		JLabel lblOdaberiDatIV3 = new JLabel("Odaberi datoteku s IV");
		JLabel lblOdaberiDatKljuc3 = new JLabel("Odaberi datoteku s ključem");		
		btnOdaberi31 = new JButton("Odaberi");			
		btnOdaberi32 = new JButton("Odaberi");		
		btnOk3 = new JButton("OK");		
		
		GroupLayout gl_pnlThree = new GroupLayout(pnlThree);
		gl_pnlThree.setHorizontalGroup(
			gl_pnlThree.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_pnlThree.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_pnlThree.createParallelGroup(Alignment.LEADING)
						.addGroup(Alignment.TRAILING, gl_pnlThree.createSequentialGroup()
							.addComponent(lblOdabirNacina3, GroupLayout.PREFERRED_SIZE, 210, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 31, Short.MAX_VALUE)
							.addComponent(btnEcb3, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(btnCbc3, GroupLayout.PREFERRED_SIZE, 61, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_pnlThree.createSequentialGroup()
							.addComponent(lblUnosPoruke3, GroupLayout.PREFERRED_SIZE, 90, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.UNRELATED)
							.addComponent(textFieldUnosPoruke3, GroupLayout.PREFERRED_SIZE, 266, GroupLayout.PREFERRED_SIZE))
						.addComponent(btnOk3, Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 54, GroupLayout.PREFERRED_SIZE)
						.addGroup(Alignment.TRAILING, gl_pnlThree.createSequentialGroup()
							.addGroup(gl_pnlThree.createParallelGroup(Alignment.LEADING)
								.addComponent(btnDekriptiraj3)
								.addComponent(lblOdaberiDatIV3, GroupLayout.PREFERRED_SIZE, 195, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(ComponentPlacement.RELATED, 88, Short.MAX_VALUE)
							.addComponent(btnOdaberi32, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_pnlThree.createSequentialGroup()
							.addComponent(lblOdaberiDatKljuc3, GroupLayout.PREFERRED_SIZE, 195, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 88, Short.MAX_VALUE)
							.addComponent(btnOdaberi31, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE))
						.addComponent(pnlRezultat3, GroupLayout.PREFERRED_SIZE, 359, GroupLayout.PREFERRED_SIZE))
					.addContainerGap())
		);
		gl_pnlThree.setVerticalGroup(
			gl_pnlThree.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_pnlThree.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_pnlThree.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_pnlThree.createSequentialGroup()
							.addGroup(gl_pnlThree.createParallelGroup(Alignment.LEADING)
								.addComponent(lblOdabirNacina3)
								.addGroup(gl_pnlThree.createParallelGroup(Alignment.BASELINE)
									.addComponent(btnCbc3)
									.addComponent(btnEcb3)))
							.addGap(18)
							.addGroup(gl_pnlThree.createParallelGroup(Alignment.LEADING)
								.addComponent(lblUnosPoruke3)
								.addComponent(textFieldUnosPoruke3, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
							.addGap(18)
							.addGroup(gl_pnlThree.createParallelGroup(Alignment.LEADING, false)
								.addGroup(gl_pnlThree.createSequentialGroup()
									.addComponent(lblOdaberiDatKljuc3)
									.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
									.addComponent(lblOdaberiDatIV3)
									.addGap(14))
								.addGroup(gl_pnlThree.createSequentialGroup()
									.addComponent(btnOdaberi31)
									.addPreferredGap(ComponentPlacement.UNRELATED)
									.addComponent(btnOdaberi32)))
							.addPreferredGap(ComponentPlacement.RELATED, 35, Short.MAX_VALUE)
							.addComponent(pnlRezultat3, GroupLayout.PREFERRED_SIZE, 78, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnOk3)
							.addContainerGap())
						.addGroup(Alignment.TRAILING, gl_pnlThree.createSequentialGroup()
							.addComponent(btnDekriptiraj3)
							.addGap(133))))
		);
		pnlThree.setLayout(gl_pnlThree);		
		JPanel pnlFour = new JPanel();
		tabbedPane.addTab("Dekriptiranje datoteke", null, pnlFour, null);
		
		JLabel lblOdabirNacina4 = new JLabel("Odabir načina dekriptiranja");
		JLabel lblOdaberiDat4 = new JLabel("Odaberi datoteku za dekriptiranje");
		JLabel lblOdaberiDatKljuc4 = new JLabel("Odaberi datoteku s ključem");
		JLabel lblOdaberiDatIV4 = new JLabel("Odaberi datoteku s IV");
		
		btnCbc4 = new JButton("CBC");		
		btnEcb4 = new JButton("ECB");		
		btnOdaberi41 = new JButton("Odaberi");		
		btnOdaberi42 = new JButton("Odaberi");		
		btnOdaberi43 = new JButton("Odaberi");		
		btnDekriptiraj4 = new JButton("Dekriptiraj");			
		JPanel pnlRezultat4 = new JPanel();
		pnlRezultat4.setBorder(new TitledBorder(null, "Rezultat", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		textFieldRezultat4 = new JTextField();
		textFieldRezultat4.setEditable(false);
		textFieldRezultat4.setColumns(10);
		
		GroupLayout gl_pnlRezultat4 = new GroupLayout(pnlRezultat4);
		gl_pnlRezultat4.setHorizontalGroup(
			gl_pnlRezultat4.createParallelGroup(Alignment.LEADING)
				.addGap(0, 362, Short.MAX_VALUE)
				.addGroup(gl_pnlRezultat4.createSequentialGroup()
					.addContainerGap()
					.addComponent(textFieldRezultat4, GroupLayout.DEFAULT_SIZE, 328, Short.MAX_VALUE)
					.addContainerGap())
		);
		gl_pnlRezultat4.setVerticalGroup(
			gl_pnlRezultat4.createParallelGroup(Alignment.LEADING)
				.addGap(0, 73, Short.MAX_VALUE)
				.addGroup(gl_pnlRezultat4.createSequentialGroup()
					.addContainerGap()
					.addComponent(textFieldRezultat4, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(20, Short.MAX_VALUE))
		);
		pnlRezultat4.setLayout(gl_pnlRezultat4);		
		btnOk4 = new JButton("OK");
		
		GroupLayout gl_pnlFour = new GroupLayout(pnlFour);
		gl_pnlFour.setHorizontalGroup(
			gl_pnlFour.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_pnlFour.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_pnlFour.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_pnlFour.createSequentialGroup()
							.addComponent(lblOdabirNacina4, GroupLayout.PREFERRED_SIZE, 210, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 25, Short.MAX_VALUE)
							.addComponent(btnEcb4, GroupLayout.PREFERRED_SIZE, 60, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(btnCbc4, GroupLayout.PREFERRED_SIZE, 61, GroupLayout.PREFERRED_SIZE))
						.addGroup(Alignment.TRAILING, gl_pnlFour.createSequentialGroup()
							.addComponent(lblOdaberiDat4)
							.addPreferredGap(ComponentPlacement.RELATED, 40, Short.MAX_VALUE)
							.addComponent(btnOdaberi41, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_pnlFour.createSequentialGroup()
							.addComponent(lblOdaberiDatKljuc4, GroupLayout.PREFERRED_SIZE, 195, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 88, Short.MAX_VALUE)
							.addComponent(btnOdaberi42, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE))
						.addGroup(gl_pnlFour.createSequentialGroup()
							.addComponent(lblOdaberiDatIV4, GroupLayout.PREFERRED_SIZE, 195, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 88, Short.MAX_VALUE)
							.addComponent(btnOdaberi43, GroupLayout.PREFERRED_SIZE, 91, GroupLayout.PREFERRED_SIZE))
						.addComponent(btnDekriptiraj4)
						.addComponent(pnlRezultat4, GroupLayout.PREFERRED_SIZE, 362, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnOk4, Alignment.TRAILING, GroupLayout.PREFERRED_SIZE, 61, GroupLayout.PREFERRED_SIZE))
					.addContainerGap())
		);
		gl_pnlFour.setVerticalGroup(
			gl_pnlFour.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_pnlFour.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_pnlFour.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_pnlFour.createParallelGroup(Alignment.BASELINE)
							.addComponent(btnCbc4)
							.addComponent(btnEcb4))
						.addComponent(lblOdabirNacina4))
					.addGap(18)
					.addGroup(gl_pnlFour.createParallelGroup(Alignment.LEADING)
						.addComponent(btnOdaberi41)
						.addComponent(lblOdaberiDat4))
					.addGap(18)
					.addGroup(gl_pnlFour.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblOdaberiDatKljuc4)
						.addComponent(btnOdaberi42))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_pnlFour.createParallelGroup(Alignment.LEADING)
						.addComponent(lblOdaberiDatIV4)
						.addComponent(btnOdaberi43))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(btnDekriptiraj4)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(pnlRezultat4, GroupLayout.PREFERRED_SIZE, 73, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addComponent(btnOk4))
		);
		pnlFour.setLayout(gl_pnlFour);
		
		MainFrame.modeEcbCbc = "ECB";
		datotekaTekst = null;	//nakon svakog koristenja ponovno postaviti na null
		datotekaKljuc = null;
		datotekaIv = null;
		
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
		}
		
		createEvents();
	}
	
	private void createEvents() {
		//kriptiranje poruke
		btnEcb1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MainFrame.modeEcbCbc = "ECB";
			}
		});
		btnCbc1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainFrame.modeEcbCbc = "CBC";
			}
		});
		btnOdaberi11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				handleFileOpenClickKljuc(e);
			}
		});
		btnOdaberi12.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				handleFileOpenClickIv(e);
			}
		});
		btnKriptiraj1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				//ovo je samo za odabir ecb
				String poruka = textFieldUnosPoruke1.getText();
				if (MainFrame.modeEcbCbc == "ECB") {
					if (MainFrame.potvrdaAlgoritma == "AES") {
						if (datotekaKljuc != null) {
							//radi s tim kljucem, dohvati kljuc Decrypter.getKeyFromFile(fileName, "AES")
							//byte[] kriptiranoAes = Encrypter.AESEncrypt(input,key);return bytArrayToHex(kriptiranoAes);
							try {
								textAreaRezultat1.setText(Encrypter.bytArrayToHex(Encrypter.stringEncryptAESecb(poruka, Decrypter.getSecretKeyFromFile(datotekaKljuc, "AES"))));
							} catch (InvalidKeyException
									| NoSuchAlgorithmException
									| NoSuchPaddingException
									| IllegalBlockSizeException
									| BadPaddingException
									| InvalidKeySpecException | IOException e1) {
								e1.printStackTrace();
							}
						}
					else {
						try {
							textAreaRezultat1.setText(Encrypter.stringEncryptECB(poruka, "AES"));
						} catch (InvalidKeyException | NoSuchAlgorithmException
							| NoSuchPaddingException
							| IllegalBlockSizeException | BadPaddingException
							| InvalidKeySpecException | IOException e1) {
								e1.printStackTrace();
							}
						}
					}
				
				else {
					if (datotekaKljuc != null){
						try {
							textAreaRezultat1.setText(Encrypter.bytArrayToHex(Encrypter.stringEncryptDESecb(poruka, Decrypter.getSecretKeyFromFile(datotekaKljuc, "DES"))));
						} catch (InvalidKeyException | NoSuchAlgorithmException
								| NoSuchPaddingException
								| IllegalBlockSizeException
								| BadPaddingException | InvalidKeySpecException
								| IOException e1) {
							e1.printStackTrace();
						}
					}
					else {
						try {
							textAreaRezultat1.setText(Encrypter.stringEncryptECB(poruka, "DES"));
						} catch (InvalidKeyException | NoSuchAlgorithmException
							| NoSuchPaddingException
							| IllegalBlockSizeException | BadPaddingException
							| InvalidKeySpecException | IOException e1) { 
								e1.printStackTrace();
							}
					}
				}
			}
			else {	//mode je CBC
					//za cbc + ispitivanje datotekaKljuc != null && datotekaIv != null
				if (MainFrame.potvrdaAlgoritma == "AES") {
					if (datotekaKljuc != null && datotekaIv != null) {	
						//radi sa ucitanim		dodaj 0 da ne treba kljuc
						try {
							textAreaRezultat1.setText(Encrypter.stringEncryptCBC(poruka, "AES",0));
						} catch (InvalidKeyException | NoSuchAlgorithmException
								| NoSuchPaddingException
								| InvalidAlgorithmParameterException
								| IllegalBlockSizeException
								| BadPaddingException | InvalidKeySpecException
								| IOException e1) {
							e1.printStackTrace();
						}	
					}
					else {
						//ovo sta je vec napisano :)
						try {
							//System.out.println("trenutni mode je " + MainFrameC.modeEcbCbc);
							textAreaRezultat1.setText(Encrypter.stringEncryptCBC(poruka, "AES",1));	
						} catch (InvalidKeyException | NoSuchAlgorithmException
								| NoSuchPaddingException
								| InvalidAlgorithmParameterException
								| IllegalBlockSizeException
								| BadPaddingException | InvalidKeySpecException
								| IOException e1) {
							e1.printStackTrace();
						}
					}
				}
				else {
					//des
					if (datotekaKljuc != null && datotekaIv != null) {
						//radi sa ucitanim dodaj 0 da ne treba kljuc
						try {
							//
							textAreaRezultat1.setText(Encrypter.stringEncryptCBC(poruka, "DES",0));
						} catch (InvalidKeyException | NoSuchAlgorithmException
								| NoSuchPaddingException
								| InvalidAlgorithmParameterException
								| IllegalBlockSizeException
								| BadPaddingException | InvalidKeySpecException
								| IOException e1) {
							e1.printStackTrace();
						}	
					}
					else {
						try {
							textAreaRezultat1.setText(Encrypter.stringEncryptCBC(poruka, "DES",1));
						} catch (InvalidKeyException | NoSuchAlgorithmException
								| NoSuchPaddingException
								| InvalidAlgorithmParameterException
								| IllegalBlockSizeException
								| BadPaddingException | InvalidKeySpecException
								| IOException e1) {
							e1.printStackTrace();
						}
					}
				}
			}
			datotekaKljuc = null;
			datotekaIv = null;
			}
		});
		
		btnOk1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		//kriptiranje datoteke
		btnEcb2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainFrame.modeEcbCbc = "ECB";
			}
		});
		btnCbc2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainFrame.modeEcbCbc = "CBC";
			}
		});
		btnOdaberi21.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				handleFileOpenClickDatoteka(e);
			}
		});
		btnOdaberi22.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				handleFileOpenClickKljuc(e);
			}
		});
		btnOdaberi23.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				handleFileOpenClickIv(e);
			}
		});
		btnKriptiraj2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (MainFrame.modeEcbCbc == "ECB") {
					if (MainFrame.potvrdaAlgoritma == "AES") {
						if (datotekaTekst != null && datotekaKljuc != null) {
							//radi sa zadanim
							try {
								textFieldRezultat2.setText(Encrypter.fileEncryptECB("AES", datotekaTekst, 0));
							} catch (InvalidKeyException
									| NoSuchAlgorithmException
									| NoSuchPaddingException | IOException e1) {
								e1.printStackTrace();
							}
						}
						else if (datotekaTekst != null) {
							//napravi svoj kljuc
							try {
								textFieldRezultat2.setText(Encrypter.fileEncryptECB("AES", datotekaTekst,1));	//1 oznacava da FileEncrypt treba napravit kljuc
							} catch (InvalidKeyException
									| NoSuchAlgorithmException
									| NoSuchPaddingException | IOException e1) {
								e1.printStackTrace();
							}
						}
						else {
							//nije zadana ni datoteka, javi gresku
							//napravi
						}
					}
					else {
						//algoritam je DES
						if (datotekaTekst != null && datotekaKljuc != null) {
							//radi sa zadanim
							try {
								textFieldRezultat2.setText(Encrypter.fileEncryptECB("DES", datotekaTekst, 0));
							} catch (InvalidKeyException
									| NoSuchAlgorithmException
									| NoSuchPaddingException | IOException e1) {
								e1.printStackTrace();
							}
						}
						else if (datotekaTekst != null) {
							//napravi svoj kljuc
							try {
								textFieldRezultat2.setText(Encrypter.fileEncryptECB("DES", datotekaTekst,1));
							} catch (InvalidKeyException
									| NoSuchAlgorithmException
									| NoSuchPaddingException | IOException e1) {
								e1.printStackTrace();
							}
						}
						else {
							//nije zadana ni datoteka, javi gresku
							//napravi
						}
					}
					
				}
				else {
					//mode je CBC
					if (MainFrame.potvrdaAlgoritma == "AES") {
						if (datotekaKljuc != null && datotekaIv != null) {	//PROVJERA DATOTEKE S TEKSTOM
							try {
								textFieldRezultat2.setText(Encrypter.fileEncryptCBC("AES", datotekaTekst, 0));
							} catch (InvalidKeyException
									| NoSuchAlgorithmException
									| NoSuchPaddingException
									| InvalidAlgorithmParameterException
									| InvalidKeySpecException | IOException e1) {
								e1.printStackTrace();
							}
						}
						else {
							try {
								textFieldRezultat2.setText(Encrypter.fileEncryptCBC("AES", datotekaTekst, 1));
							} catch (InvalidKeyException
									| NoSuchAlgorithmException
									| NoSuchPaddingException
									| InvalidAlgorithmParameterException
									| InvalidKeySpecException | IOException e1) {
								e1.printStackTrace();
							}
						}
					}
					else {
						//des
						if (datotekaKljuc != null && datotekaIv != null) {
							try {
								textFieldRezultat2.setText(Encrypter.fileEncryptCBC("DES", datotekaTekst, 0));
							} catch (InvalidKeyException
									| NoSuchAlgorithmException
									| NoSuchPaddingException
									| InvalidAlgorithmParameterException
									| InvalidKeySpecException | IOException e1) {
								e1.printStackTrace();
							}
						}
						else {
							try {
								textFieldRezultat2.setText(Encrypter.fileEncryptCBC("DES", datotekaTekst, 1));
							} catch (InvalidKeyException
									| NoSuchAlgorithmException
									| NoSuchPaddingException
									| InvalidAlgorithmParameterException
									| InvalidKeySpecException | IOException e1) {
								e1.printStackTrace();
							}
						}
					}
					
				}
				datotekaKljuc = null;
				datotekaIv = null;
				datotekaTekst = null;
			}
		});
		btnOk2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		
		//dekriptiranje poruke
		btnEcb3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainFrame.modeEcbCbc = "ECB";
			}
		});
		btnCbc3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainFrame.modeEcbCbc = "CBC";
			}
		});
		btnOdaberi31.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				handleFileOpenClickKljuc(e);
			}
		});
		btnOdaberi32.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				handleFileOpenClickIv(e);
			}
		});
		btnDekriptiraj3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String poruka = textFieldUnosPoruke3.getText();
				if (MainFrame.modeEcbCbc == "ECB") {
					if (MainFrame.potvrdaAlgoritma == "AES") {
						if (datotekaKljuc != null) {
							try {
								textAreaRezultat3.setText(Decrypter.stringDecryptAESecb(Decrypter.hexStringToByteArray(poruka), Decrypter.getSecretKeyFromFile(datotekaKljuc, "AES")));
							} catch (InvalidKeyException
									| NoSuchAlgorithmException
									| NoSuchPaddingException
									| IllegalBlockSizeException
									| BadPaddingException
									| InvalidKeySpecException | IOException e1) {
								e1.printStackTrace();
							}
							
						}
						else {
							//javi gresku ili ne radi nista :)
						}
					}
					else {
						//des
						if (datotekaKljuc != null) {
							try {
								textAreaRezultat3.setText(Decrypter.stringDecryptDESecb(Decrypter.hexStringToByteArray(poruka), Decrypter.getSecretKeyFromFile(datotekaKljuc, "DES")));
							} catch (InvalidKeyException
									| NoSuchAlgorithmException
									| NoSuchPaddingException
									| IllegalBlockSizeException
									| BadPaddingException
									| InvalidKeySpecException | IOException e1) {
								e1.printStackTrace();
							}
						}
						else {
							//javi gresku ili nista
						}
					}
				}
				
				else {
					//mode je CBC
					if (MainFrame.potvrdaAlgoritma == "AES") {
						if (datotekaKljuc != null && datotekaIv != null) {
							//radi sa zadanim
							try {
								try {
									textAreaRezultat3.setText(new String(Decrypter.hexStringToByteArray(Decrypter.stringDecryptCBC(Decrypter.hexStringToByteArray(poruka), "AES"))));
								} catch (InvalidKeyException
										| InvalidAlgorithmParameterException
										| IllegalBlockSizeException
										| BadPaddingException
										| InvalidKeySpecException | IOException e1) {
									e1.printStackTrace();
								}
							} catch (NoSuchAlgorithmException
									| NoSuchPaddingException e1) {
								e1.printStackTrace();
							}
						}
						else {
							//javi gresku ili nista
						}
					}
					else {
						//des
						if (datotekaKljuc != null && datotekaIv != null) {
							//radi sa zadanim
							try {
								try {
									textAreaRezultat3.setText(new String(Decrypter.hexStringToByteArray(Decrypter.stringDecryptCBC(Decrypter.hexStringToByteArray(poruka), "DES"))));
								} catch (InvalidKeyException
										| InvalidAlgorithmParameterException
										| IllegalBlockSizeException
										| BadPaddingException
										| InvalidKeySpecException | IOException e1) {
									e1.printStackTrace();
								}
							} catch (NoSuchAlgorithmException
									| NoSuchPaddingException e1) {
								e1.printStackTrace();
							}
						}
						else {
							//javi gresku ili nista
						}
					}
				}
				
				
				
				
			datotekaKljuc = null;
			datotekaIv = null;
			datotekaTekst = null;	
			}
		});
		btnOk3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		//dekriptiranje datoteke
		btnEcb4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainFrame.modeEcbCbc = "ECB";
			}
		});
		btnCbc4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				MainFrame.modeEcbCbc = "CBC";
			}
		});
		btnOdaberi41.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				handleFileOpenClickDatoteka(e);
			}
		});
		btnOdaberi42.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				handleFileOpenClickKljuc(e);
			}
		});
		btnOdaberi43.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				handleFileOpenClickIv(e);
			}
		});
		btnDekriptiraj4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (MainFrame.modeEcbCbc == "ECB") {
					if (MainFrame.potvrdaAlgoritma == "AES") {			//provjeri dal je uopce ucitana datoteka kljuc, ako nije greska ili nesto
						try {
							textFieldRezultat4.setText(Decrypter.fileDecryptECB(datotekaTekst, Decrypter.getSecretKeyFromFile(datotekaKljuc,"AES"),"AES"));
						} catch (InvalidKeyException | NoSuchAlgorithmException
								| NoSuchPaddingException | InvalidKeySpecException
								| IOException e1) {
							e1.printStackTrace();
						}
					}
					else {
						try {
							textFieldRezultat4.setText(Decrypter.fileDecryptECB(datotekaTekst, Decrypter.getSecretKeyFromFile(datotekaKljuc,"DES"),"DES"));
						} catch (InvalidKeyException | NoSuchAlgorithmException
								| NoSuchPaddingException | InvalidKeySpecException
								| IOException e1) {
							e1.printStackTrace();
						}
					}
				}
				else {
					//cbc
					if (MainFrame.potvrdaAlgoritma == "AES") {
						if (datotekaKljuc != null && datotekaIv != null) {
							//radi sa zadanim
							//textFieldRezultat4.setText(Decrypter.decryptFile(datotekaTekst, Decrypter.getKeyFromFile(datotekaKljuc,"AES"),"AES"));
							try {
								textFieldRezultat4.setText(Decrypter.fileDecryptCBC(datotekaTekst, Decrypter.getSecretKeyFromFile(datotekaKljuc, "AES"), datotekaIv, "AES"));
							} catch (InvalidKeyException
									| NoSuchAlgorithmException
									| NoSuchPaddingException
									| InvalidAlgorithmParameterException
									| InvalidKeySpecException | IOException e1) {
								e1.printStackTrace();
							}
						}
						else {
							//javi gresku ili nesto ili nista
						}
					}
					else {
						//des
						if (datotekaKljuc != null && datotekaIv != null) {
							try {
								textFieldRezultat4.setText(Decrypter.fileDecryptCBC(datotekaTekst, Decrypter.getSecretKeyFromFile(datotekaKljuc, "DES"), datotekaIv, "DES"));
							} catch (InvalidKeyException
									| NoSuchAlgorithmException
									| NoSuchPaddingException
									| InvalidAlgorithmParameterException
									| InvalidKeySpecException | IOException e1) {
								e1.printStackTrace();
							}
						}
						else {
							//javi gresku ili nista
						}
					}
				}
				
			}
		});
		btnOk4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
	}
	private void handleFileOpenClickDatoteka(ActionEvent arg0) {
		JFileChooser chooser = new JFileChooser();
		FileNameExtensionFilter filter = new FileNameExtensionFilter(
		    "TXT files", "txt");
		chooser.setFileFilter(filter);
		int returnVal = chooser.showOpenDialog(this);
		if(returnVal == JFileChooser.APPROVE_OPTION) {
			datotekaTekst = chooser.getSelectedFile().getPath();
		}
	}
	private void handleFileOpenClickKljuc(ActionEvent arg0) {
		JFileChooser chooser = new JFileChooser();
		FileNameExtensionFilter filter = new FileNameExtensionFilter(
		    "TXT files", "txt");
		chooser.setFileFilter(filter);
		int returnVal = chooser.showOpenDialog(this);
		if(returnVal == JFileChooser.APPROVE_OPTION) {
			datotekaKljuc = chooser.getSelectedFile().getPath();
		}
	}
	private void handleFileOpenClickIv(ActionEvent arg0) {
		JFileChooser chooser = new JFileChooser();
		FileNameExtensionFilter filter = new FileNameExtensionFilter(
		    "TXT files", "txt");
		chooser.setFileFilter(filter);
		int returnVal = chooser.showOpenDialog(this);
		if(returnVal == JFileChooser.APPROVE_OPTION) {
			datotekaIv = chooser.getSelectedFile().getPath();
		}
	}
}
