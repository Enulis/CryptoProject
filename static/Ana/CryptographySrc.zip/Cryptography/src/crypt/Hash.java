package crypt;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/** Izrada sazetka poruke algoritmima MD5 i SHA-1
 * @param	String input - poruka od koje se radi sazetak
 * 			String hash - naziv algoritma
 * @return	sazetak poruke
 */
public class Hash {
	public static String makeMessageDigest(String input, String hash) throws NoSuchAlgorithmException {
		String rezultat = null;
		switch(hash) {
		case "MD5" : 
			MessageDigest digest2 = MessageDigest.getInstance("MD5");
			digest2.update(input.getBytes());
			rezultat = Encrypter.bytArrayToHex(digest2.digest());
			break;
		case "SHA-1" :
			MessageDigest digest3 = MessageDigest.getInstance("SHA-1");
			digest3.update(input.getBytes());
			rezultat = Encrypter.bytArrayToHex(digest3.digest());
			break;
		}
		return rezultat;
	}
}
