package crypt;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.CipherOutputStream;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

public class Encrypter {
	
	
	public static SecretKey key;
	public static SecretKey key2;
	public static IvParameterSpec ivSpec;
	
	/** Kriptiranje stringa AES ili DES algoritmom i ECB nacinom
	 * @param	String input - string koji se kriptira	
	 * 			String alg - algoritam kojim se kriptira npr. AES, DES
	 * @return	kriptirani string
	 */
	public static String stringEncryptECB (String input, String alg) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, IOException, InvalidKeySpecException{
		if (alg == "AES") {
			SecretKey key = KeyGenerator.GenerateKey(Algorithm.AES);
			byte[] kriptiranoAes = Encrypter.stringEncryptAESecb(input,key);
			return bytArrayToHex(kriptiranoAes);
		}
		else {
			SecretKey key = KeyGenerator.GenerateKey(Algorithm.DES);
			byte[] kriptiranoDes = Encrypter.stringEncryptDESecb(input, key);
			return bytArrayToHex(kriptiranoDes);
		}
	}
	
	/** Kriptiranje stringa AES algoritmom i ECB nacinom
	 * @param	String input - niz bajtova koji treba sifrirati
	 * 			SecretKey key - kljuc potreban za sifriranje
	 * @return	niz kriptiranih bajtova
	 */
	public static byte[] stringEncryptAESecb(String input, SecretKey key) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, IOException {
		String transformation = "AES/ECB/PKCS5Padding";	
		Cipher cipher = Cipher.getInstance(transformation);	
		saveSecretKeyToFile(key);
		cipher.init(Cipher.ENCRYPT_MODE, key);
		return cipher.doFinal(input.getBytes());
	}
	
	/** Kriptiranje stringa DES algoritmom i ECB nacinom
	 * @param	String input - niz bajtova koji treba sifrirati
	 * 			SecretKey key - kljuc potreban za sifriranje
	 * @return	niz kriptiranih bajtova
	 */
	public static byte[] stringEncryptDESecb(String input, SecretKey key) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, IOException {
		String transformation = "DES/ECB/PKCS5Padding";
		Cipher cipher = Cipher.getInstance(transformation);
		saveSecretKeyToFile(key);	
		cipher.init(Cipher.ENCRYPT_MODE, key);		
		return cipher.doFinal(input.getBytes());
	}
	
	/** Kriptiranje stringa AES ili DES algoritmom i CBC nacinom
	 * @param	String input - string koji se kriptira	
	 * 			String alg - algoritam kojim se kriptira npr. AES, DES
	 * 			int trebaKljuc - ako je 0 to znaci da se kljuc ucitava iz datoteke, ako je 1 potrebna je izrada
	 * 						 novog kljuca
	 * @return	kriptirani string
	 */
	public static String stringEncryptCBC (String input, String alg, int trebaKljuc) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, IOException, InvalidKeySpecException {
		if (alg == "AES") {
			if (trebaKljuc == 1) {
				key = KeyGenerator.GenerateKey(Algorithm.AES);
				Encrypter.saveSecretKeyToFile(key);
				ivSpec = getIv(16);	
			}
			else {
				//ucitaj iz datoteke.
				key = Decrypter.getSecretKeyFromFile(CryptDialog.datotekaKljuc, MainFrame.potvrdaAlgoritma);
				ivSpec = Decrypter.makeIvFromFile(CryptDialog.datotekaIv);
			}
			
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, key, ivSpec);
			byte[] kriptirano = cipher.doFinal(input.getBytes());	//provjeri
			return Encrypter.bytArrayToHex(kriptirano);
		}
		else {
			if (trebaKljuc == 1) {
				key = KeyGenerator.GenerateKey(Algorithm.DES);
				Encrypter.saveSecretKeyToFile(key);
				ivSpec = getIv(8);
			}
			else {
				key = Decrypter.getSecretKeyFromFile(CryptDialog.datotekaKljuc, MainFrame.potvrdaAlgoritma);
				ivSpec = Decrypter.makeIvFromFile(CryptDialog.datotekaIv);
			}
			
			Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
			cipher.init(Cipher.ENCRYPT_MODE, key, ivSpec);
			byte[] kriptirano = cipher.doFinal(input.getBytes());	//provjeri
			return Encrypter.bytArrayToHex(kriptirano);
		}
	}
	
	/** Kriptiranje datoteke AES ili DES algoritmom i ECB nacinom
	 * @param	String alg - algoritam kojim se kriptira npr. AES, DES
	 * 			String fileName - naziv datoteke koja se kriptira
	 * 			int trebaKljuc - ako je 0 to znaci da se kljuc ucitava iz datoteke, ako je 1 potrebna je izrada
	 * 						 novog kljuca
	 * @return	naziv kriptirane datoteke
	 */
	public static String fileEncryptECB(String alg, String fileName, int trebaKljuc) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IOException {
		String transform = alg + "/ECB/PKCS5Padding";
		Cipher cipher = Cipher.getInstance(transform);
		
		switch (alg) {
		case "AES" :
			if (trebaKljuc == 1) {
				key = KeyGenerator.GenerateKey(Algorithm.AES);
			}
			else {
				try {
					key = Decrypter.getSecretKeyFromFile(CryptDialog.datotekaKljuc, MainFrame.potvrdaAlgoritma);
				} catch (InvalidKeySpecException e) {
					e.printStackTrace();
				}
			}
			
			saveSecretKeyToFile(key);
			cipher.init(Cipher.ENCRYPT_MODE, key);
			
			FileInputStream fis = new FileInputStream(fileName);
			FileOutputStream fos = new FileOutputStream("encryptedFile.txt");
			CipherOutputStream cos = new CipherOutputStream(fos, cipher);
			
			byte[] block = new byte[32];
			int i=0;
			while ((i = fis.read(block)) != -1) {
			cos.write(block,0,i);	
			}
			cos.close();
			fis.close();
			break;				
			
		case "DES" :
			if (trebaKljuc == 1) {
				key2 = KeyGenerator.GenerateKey(Algorithm.DES);
			}
			else {
				try {
					key2 = Decrypter.getSecretKeyFromFile(CryptDialog.datotekaKljuc, MainFrame.potvrdaAlgoritma);
				} catch (InvalidKeySpecException e) {
					e.printStackTrace();
				}
			}
			
			cipher.init(Cipher.ENCRYPT_MODE, key2);
			saveSecretKeyToFile(key2);
			FileInputStream fiss = new FileInputStream(fileName);
			FileOutputStream foss = new FileOutputStream("encryptedFile.txt");
			CipherOutputStream coss = new CipherOutputStream(foss, cipher);
			
			byte[] blockk = new byte[32];
			int ii=0;
			while ((ii = fiss.read(blockk)) != -1) {
			coss.write(blockk,0,ii);	
			}
			coss.close();
			fiss.close();
			break;
		}		
		return "encryptedFile.txt";
	}
	
	/** Kriptiranje datoteke AES ili DES algoritmom i CBC nacinom
	 * @param	String alg - algoritam kojim se kriptira npr. AES, DES
	 * 			String fileName - naziv datoteke koja se kriptira
	 * 			int trebaKljuc - ako je 0 to znaci da se kljuc ucitava iz datoteke, ako je 1 potrebna je izrada
	 * 						 novog kljuca
	 * @return	naziv kriptirane datoteke
	 */
	public static String fileEncryptCBC(String alg, String fileName, int trebaKljuc) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IOException, InvalidAlgorithmParameterException, InvalidKeySpecException {
		String transform = alg + "/CBC" + "/PKCS5Padding";
		Cipher cipher = Cipher.getInstance(transform);
		
		if (alg == "AES") {
			if (trebaKljuc == 1) {
				key = KeyGenerator.GenerateKey(Algorithm.AES);
				Encrypter.saveSecretKeyToFile(key);
				ivSpec = getIv(cipher.getBlockSize());
			}
			else {
				//ne treba kljuc, ucitaj iz varijabli datotekaTekst i slicno
				key = Decrypter.getSecretKeyFromFile(CryptDialog.datotekaKljuc, MainFrame.potvrdaAlgoritma);
				ivSpec = Decrypter.makeIvFromFile(CryptDialog.datotekaIv);
			}
		}
		else {
			//des
			if (trebaKljuc == 1) {
				key = KeyGenerator.GenerateKey(Algorithm.DES);
				Encrypter.saveSecretKeyToFile(key);
				ivSpec = getIv(cipher.getBlockSize());
			}
			else {
				key = Decrypter.getSecretKeyFromFile(CryptDialog.datotekaKljuc, MainFrame.potvrdaAlgoritma);
				ivSpec = Decrypter.makeIvFromFile(CryptDialog.datotekaIv);
			}
		}
		
		cipher.init(Cipher.ENCRYPT_MODE, key, ivSpec);
		FileInputStream fis = new FileInputStream(fileName);
		FileOutputStream fos = new FileOutputStream("encryptedFileCBC.txt");
		CipherOutputStream cos = new CipherOutputStream(fos, cipher);
		
		byte[] block = new byte[32];
		int i;
		while ((i = fis.read(block)) != -1) {
		cos.write(block,0,i);	
		}
		cos.close();
		fis.close();
		
		return "encryptedFileCBC.txt";
	}
	
	/** Spremanje tajnog kljuca u datoteku
	 * @param	SecretKey key - kljuc koji se sprema u datoteku
	 */
	public static void saveSecretKeyToFile(SecretKey key) throws IOException {
		byte[] keyBytes = key.getEncoded();
		FileOutputStream izlaz = new FileOutputStream( MainFrame.potvrdaAlgoritma + "SecretKey.txt");
				
		int i;
		for (i=0; i < keyBytes.length; i++) {
			izlaz.write(keyBytes[i]);
		}
		izlaz.close();
	}
	
	/** Izrada inicijalizacijskog vektora
	 * @param	int blockSize - velicina vektora
	 */
	public static IvParameterSpec getIv (int blockSize) throws IOException {
		byte[] iv = new byte[blockSize];
		new SecureRandom().nextBytes(iv);
		saveIvToFile(iv);
		IvParameterSpec ivSpec = new IvParameterSpec(iv);
		return ivSpec;
	}
	
	/** Spremanje materijala za izradu inicijalizacijskog vektora
	 * @param	byte[] iv - niz bajtova od kojih se radi inicijalizacijski vektor
	 */
	public static void saveIvToFile(byte[] iv) throws IOException {
		FileOutputStream fs = new FileOutputStream(new File("iv.txt"));
        BufferedOutputStream bos = new BufferedOutputStream(fs);
        bos.write(iv);
        bos.close();
	}
	
	/** Pretvaranje niza bajtova u heksadekadski string
	 * @param	 byte[] a - niz bajtova koji treba pretvoriti
	 * @return	heksadekadski string
	 */
	public static String bytArrayToHex(byte[] a) {
		StringBuilder sb = new StringBuilder();
		for(byte b: a) sb.append(String.format("%02x", b&0xff));
		return sb.toString();
	}
}
