package crypt;

import javax.swing.JFrame;
import javax.swing.SwingUtilities;


/** Pokretanje Java aplikacije "Kriptografski algoritmi"
 */
public class CryptApp {
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				JFrame frame = new MainFrame("Kriptografski algoritmi");
				frame.setSize(400, 420);
				frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				frame.setVisible(true);
			}
		});
	}
}
