package crypt;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class Decrypter {
	
	public static SecretKey key;
	public static IvParameterSpec ivSpec;
	
	/** Dekriptiranje stringa AES algoritmom i ECB nacinom
	 * @param	byte[] input - niz bajtova koji treba desifrirati
	 * 			SecretKey key - kljuc potreban za desifriranje
	 * @return	dekriptirani string
	 */
	public static String stringDecryptAESecb(byte[] input, SecretKey key) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		String transformation = "AES/ECB/PKCS5Padding";	
		Cipher cipher = Cipher.getInstance(transformation);		
		cipher.init(Cipher.DECRYPT_MODE, key);
		return new String(cipher.doFinal(input));
	}
	/** Dekriptiranje stringa DES algoritmom i ECB nacinom
	 * @param	byte[] input - niz bajtova koji treba desifrirati
	 * 			SecretKey key - kljuc potreban za desifriranje
	 * @return	dekriptirani string
	 */
	public static String stringDecryptDESecb(byte[] input, SecretKey key) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		String transformation = "DES/ECB/PKCS5Padding";
		Cipher cipher = Cipher.getInstance(transformation);	
		cipher.init(Cipher.DECRYPT_MODE, key);
		byte[] decrypted = cipher.doFinal(input);
		return new String(decrypted);
	}
	
	/** Kriptiranje striga AES ili DES algoritmom i CBC nacinom
	 * @param	byte[] input - niz bajtova koji treba kriptirati
	 * 			String alg - algoritam kojim se kriptira npr. AES ili DES
	 * @return	dekriptirani string
	 */
	public static String stringDecryptCBC (byte[] input, String alg) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, InvalidAlgorithmParameterException, IllegalBlockSizeException, BadPaddingException, IOException, InvalidKeySpecException {
		if (alg == "AES") {
			key = Decrypter.getSecretKeyFromFile(CryptDialog.datotekaKljuc, MainFrame.potvrdaAlgoritma);
			ivSpec = Decrypter.makeIvFromFile(CryptDialog.datotekaIv);
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE, key, ivSpec);
			byte[] dekriptirano = cipher.doFinal(input);	//provjeri
			return Encrypter.bytArrayToHex(dekriptirano);	//format?
		}
		else {
			key = Decrypter.getSecretKeyFromFile(CryptDialog.datotekaKljuc, MainFrame.potvrdaAlgoritma);
			ivSpec = Decrypter.makeIvFromFile(CryptDialog.datotekaIv);	
			Cipher cipher = Cipher.getInstance("DES/CBC/PKCS5Padding");
			cipher.init(Cipher.DECRYPT_MODE, key, ivSpec);
			byte[] dekriptirano = cipher.doFinal(input);	//provjeri
			return Encrypter.bytArrayToHex(dekriptirano);
		}
	}
	
	/** Dekriptiranje datoteke s AES ili DES algoritmom i ECB nacinom; potrebno uzeti spremljeni kljuc iz datoteke
	 * @param	String fileName - ime datoteke koju je potrebno desifrirati
	 * 			SecretKey key - kljuc potreban za desifriranje
	 * 			String alg - algoritam kojim je datoteka sifrirana i koji ce se koristiti za desifiranje
	 * @return	naziv dekriptirane datoteke
	 */
	public static String fileDecryptECB(String fileName, SecretKey key, String alg) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IOException {
		Cipher ciph = Cipher.getInstance(alg + "/ECB/PKCS5Padding");
		ciph.init(Cipher.DECRYPT_MODE,  key);
		FileInputStream fis5 = new FileInputStream(fileName);
		CipherInputStream cis5 = new CipherInputStream(fis5, ciph);
		FileOutputStream fos5 = new FileOutputStream("decryptedFile.txt");
		
		byte[] block5 = new byte[32];
		int n;
		while ((n = cis5.read(block5)) != -1) {
		fos5.write(block5, 0, n);
		}
		cis5.close();
		fos5.close();
		
		return "decryptedFile.txt";
	}
	
	/** Dekriptiranje datoteke koja je kriptirana AES ili DES algoritmom i CBC nacinom
	 * @param	String fileName - ime datoteke koju treba kriptirati
	 * 			SecretKey key - kljuc kojim je kriptirana datoteka
	 * 			String paramFile - naziv datoteke u kojoj je spremljen inicijalizacijski vektor
	 * 			String alg - algoritam kojim je kriptirana datoteka
	 * @return	naziv dekriptirane datoteke
	 */
	public static String fileDecryptCBC(String fileName, SecretKey key, String paramFile, String alg) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IOException, InvalidAlgorithmParameterException {
		Cipher ciph = Cipher.getInstance(alg + "/CBC/PKCS5Padding");
		IvParameterSpec ivSpec = makeIvFromFile(paramFile);
		ciph.init(Cipher.DECRYPT_MODE, key, ivSpec);
		FileInputStream fis5 = new FileInputStream(fileName);
		CipherInputStream cis5 = new CipherInputStream(fis5, ciph);
		FileOutputStream fos5 = new FileOutputStream("decryptedFileCBC");
		
		byte[] block5 = new byte[32];
		int n;
		
		while ((n = cis5.read(block5)) != -1) {
		fos5.write(block5, 0, n);
		}
		cis5.close();
		fos5.close();
		
		return "decryptedFileCBC";
	}
	
	/** Dohvacanje spremljenog kljuca iz datoteke
	 * @param	String fileName - ime datoteke iz koje se dohvaca kljuc
	 * 			String algorithm - algoritam kojim je datoteka sifrirana i koji ce se koristiti za desifriranje
	 * @return	tajni kljuc
	 */
	public static SecretKey getSecretKeyFromFile(String fileName, String algorithm) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {
		File file = new File(fileName);
        byte[] keyBytes = new byte[(int) file.length()];
        FileInputStream fileInputStream = new FileInputStream(file);
        fileInputStream.read(keyBytes);

        SecretKey key2 = new SecretKeySpec(keyBytes, 0, keyBytes.length, algorithm);	
        fileInputStream.close();
        return key2;
	}
	
	/** Izrada inicijalizacijskog vektora na temelju podataka spremljenih u datoteku
	 * @param	String paramFile - ime datoteke u kojoj je spremljen inicijalizacijski vektor
	 * @return	inicijalizacijski vektor
	 */
	public static IvParameterSpec makeIvFromFile(String paramFile) throws IOException {
		File file = new File(paramFile);
        byte[] ivBytes = new byte[(int) file.length()];
        FileInputStream fileInputStream = new FileInputStream(file);
        fileInputStream.read(ivBytes);
		IvParameterSpec ivSpec = new IvParameterSpec(ivBytes);
		fileInputStream.close();
		return ivSpec;
	}
	
	/** Pretvaranje hesadekadskog stringa u niz bajtova
	 * @param	String s - heksadekadski string koji je potrebno prebaciti
	 * @return	niz bajtova
	 */
	public static byte[] hexStringToByteArray(String s) {
	    byte[] b = new byte[s.length() / 2];
	    for (int i = 0; i < b.length; i++) {
	      int index = i * 2;
	      int v = Integer.parseInt(s.substring(index, index + 2), 16);
	      b[i] = (byte) v;
	    }
	    return b;
	  }	
}
