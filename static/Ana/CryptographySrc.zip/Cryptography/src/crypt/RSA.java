package crypt;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.security.InvalidKeyException;
import java.security.KeyFactory;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.EncodedKeySpec;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.PKCS8EncodedKeySpec;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

/** Kriptiranje i dekriptiranje poruka i datoteka RSA algorimom
 */
public class RSA {
	public static void main() throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, IOException, InvalidKeySpecException {	
	}
	
	/** Kriptiranje stringa algoritmom RSA
	 * @param	String input - string koji se kriptira
	 * @return	kriptirani string
	 */
	public static String stringEncryptRSA(String input) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, IOException, InvalidKeySpecException{
		
		Cipher cipher = Cipher.getInstance("RSA");
		KeyPair kp = generateRSAKey();	
		saveRSAKeyToFile(kp.getPrivate());
		PublicKey publicKey = kp.getPublic();
		cipher.init(Cipher.ENCRYPT_MODE, publicKey);
		return Encrypter.bytArrayToHex(cipher.doFinal(input.getBytes()));
	}
	
	/** Kriptiranje datoteke algoritmom RSA
	 * @param	String fileName - ime datoteke koja se kriptira
	 * @return	naziv kriptirane datoteke
	 */
	public static String fileEncryptRSA(String fileName) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IOException{
		Cipher cipher = Cipher.getInstance("RSA");
		KeyPair kp = generateRSAKey();	
		cipher.init(Cipher.ENCRYPT_MODE, kp.getPublic());
		saveRSAKeyToFile(kp.getPrivate());
		FileInputStream fis = new FileInputStream(fileName);
		FileOutputStream fos = new FileOutputStream("encryptedFileRSA.txt");
		CipherOutputStream cos = new CipherOutputStream(fos, cipher);
		
		byte[] block = new byte[32];
		int i;
		while ((i = fis.read(block)) != -1) {
		cos.write(block,0,i);	
		}
		cos.close();
		fis.close();
		
		return "encryptedFileRSA.txt";
	}
	
	/** Dekriptiranje stringa koji je kriptiran RSA algoritmom
	 * @param	byte[] input - niz bajtova koji je potrebno dekriptirati
	 * 			String fileName - ime datoteke u koju je spremljen kljuc kojim je kriptiran string
	 * @return	dekriptirani string
	 */
	public static String stringDecryptRSA(byte[] input, String fileName) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, InvalidKeySpecException, IOException {
		PrivateKey privateKey = getRSAKeyFromFile(fileName);
		Cipher cipher = Cipher.getInstance("RSA");
		cipher.init(Cipher.DECRYPT_MODE, privateKey);
		return Encrypter.bytArrayToHex(cipher.doFinal(input));
	}
	
	/** Dekriptiranje datoteke koja je kriptirana RSA algoritmom
	 * @param	String fileName - ime datoteke koju je potrebno dekriptirati
	 * 			PrivateKey privateKey - kljuc kojim je kriptirana datoteka
	 * @return	naziv dekriptirane datoteke
	 */
	public static String fileDecryptRSA(String fileName, PrivateKey privateKey) throws NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IOException {
		Cipher cipher = Cipher.getInstance("RSA");
		cipher.init(Cipher.DECRYPT_MODE,  privateKey);
		FileInputStream fis5 = new FileInputStream(fileName);
		CipherInputStream cis5 = new CipherInputStream(fis5, cipher);
		FileOutputStream fos5 = new FileOutputStream("decryptedFileRSA.txt");
		
		byte[] block5 = new byte[32];
		int n;
		
		while ((n = cis5.read(block5)) != -1) {
		fos5.write(block5, 0, n);
		}
		cis5.close();
		fos5.close();
		return "decryptedFileRSA.txt";
	}

	/** Generiranje para kljuceva
	 * @return	RSA par kljuceva
	 */
	public static KeyPair generateRSAKey() throws NoSuchAlgorithmException{
		KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
		keyGen.initialize(1024);			//ili 2048
		return keyGen.genKeyPair();
	}
	
	/** Spremanje privatnog RSA kljuca u datoteku
	 * @param	PrivateKey privateKey - kljuc koji se sprema u datoteku
	 */
	public static void saveRSAKeyToFile(PrivateKey privateKey) throws IOException {
		byte[] privateKeyBytes = privateKey.getEncoded();
		FileOutputStream izlaz = new FileOutputStream("privateRSAKey.txt");

		int i;
		for (i=0; i < privateKeyBytes.length; i++) {
			izlaz.write(privateKeyBytes[i]);
		}
		izlaz.close();
	}
	
	/** Dohvacanje privatnog RSA kljuca iz datoteke
	 * @param	String fileName - ime datoteke u koju je spremljen kljuc
	 * @return	RSA privatni kljuc
	 */
	public static PrivateKey getRSAKeyFromFile(String fileName) throws IOException, NoSuchAlgorithmException, InvalidKeySpecException {

		File file = new File(fileName);
        byte[] privateKeyBytes = new byte[(int) file.length()];
        FileInputStream fileInputStream = new FileInputStream(file);
        fileInputStream.read(privateKeyBytes);
        fileInputStream.close();
		
		KeyFactory keyFactory = KeyFactory.getInstance("RSA");
	    EncodedKeySpec privateKeySpec = new PKCS8EncodedKeySpec(privateKeyBytes);
	    PrivateKey privateKey2 = keyFactory.generatePrivate(privateKeySpec);
	    return privateKey2;
	}	
}
