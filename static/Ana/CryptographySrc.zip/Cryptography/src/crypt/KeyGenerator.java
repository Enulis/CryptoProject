package crypt;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;


public class KeyGenerator {
	/** Generiranje kljuceva za AES li DES algoritam
	 * @param	Algorithm algoritam - za koji algoritam se radi kljuc
	 */
	public static SecretKey GenerateKey(Algorithm algorithm) throws NoSuchAlgorithmException {
		switch (algorithm) {
		case AES:
			return GenerateAESKey();
		case DES:
			return GenerateDESKey();
		default:
			throw new NoSuchAlgorithmException(); 
		}
	}
	/** Generiranje DES kljuca
	 * @return	tajni DES kljuc
	 */
	private static SecretKey GenerateDESKey() throws NoSuchAlgorithmException {
		return javax.crypto.KeyGenerator.getInstance("DES").generateKey();
	}
	
	/** Generiranje AES kljuca
	 * @return	tajni AES kljuc
	 */
	private static SecretKey GenerateAESKey() throws NoSuchAlgorithmException {
		MessageDigest digest = MessageDigest.getInstance("SHA-256");
		String keyString = "23750ergoujnfv1093eusjxknmncdftwuz3erhwlei43784ioirek";
		digest.update(keyString.getBytes());
		
		byte[] key = new byte[16];
		System.arraycopy(digest.digest(), 0, key, 0, key.length);	
		SecretKeySpec keySpec = new SecretKeySpec(key, "AES");
		return keySpec;
	}
}
