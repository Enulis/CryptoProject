Pokretanje

1.način : Dvostruki klik na CryptographyInJava.jar

2.način : U konzoli se pozicionirate na direktorij u kojem se nalazi CryptographyInJava.jar
		Zatim upišete java -jar CryptographyInJava.jar i pritisnete enter.