package crypt;

import java.awt.BorderLayout;
import java.awt.FlowLayout;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JTextArea;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class MyError extends JDialog {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -3234287924037398730L;
	private JButton btnOk;
	private final JPanel contentPanel = new JPanel();

	/**
	 * Create the dialog.
	 */
	public MyError(int greska) {
		setBounds(100, 100, 350, 200);
		setTitle("Dojava o pogrešci");
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		
		JTextArea textArea = new JTextArea();
		textArea.setLineWrap(true);
		textArea.setWrapStyleWord(true);
		textArea.setEditable(false);
		
		btnOk = new JButton("OK");
		GroupLayout gl_contentPanel = new GroupLayout(contentPanel);
		gl_contentPanel.setHorizontalGroup(
			gl_contentPanel.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPanel.createSequentialGroup()
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addGroup(gl_contentPanel.createParallelGroup(Alignment.TRAILING)
						.addComponent(btnOk)
						.addComponent(textArea, GroupLayout.PREFERRED_SIZE, 309, GroupLayout.PREFERRED_SIZE))
					.addContainerGap())
		);
		gl_contentPanel.setVerticalGroup(
			gl_contentPanel.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPanel.createSequentialGroup()
					.addGap(24)
					.addComponent(textArea, GroupLayout.PREFERRED_SIZE, 77, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(btnOk)
					.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
		);
		contentPanel.setLayout(gl_contentPanel);
		{
			JPanel buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
		}
		
	if (greska == 1) {
		textArea.setText("Datoteka s ključem ne sadrži odgovarajući ključ.");
	}
	else if (greska == 2) {
		textArea.setText("Neocekivana pogreška!");
	}
	else if (greska == 3) {
		textArea.setText("Tekst nije kriptiran odgovarajućim algoritmom.");
	}
	else if (greska == 4) {
		textArea.setText("Datoteka s ključem ne sadrži odgovarajući ključ ili datoteka s inicijalizacijskim vektorom ne sadrži odgovarajući vektor (CBC način).");
	}
	else if (greska == 5) {
		setTitle("Upute");
		textArea.setText("Ukoliko je odabrana datoteka s nepravilnim ključem, algoritam će napravit novi ključ i spremiti ga u tekstualnu datoteku. Polja označena zvjezdicom su opcionalna.");
	}
	else if (greska == 6) {
		setTitle("Upute");
		textArea.setText("Ukoliko je dekriptirana datoteka prazna to znači da je odabrana datoteka s tekstom koji nije kriptiran odgovarajućim algoritmom.");
	}
	else if (greska == 7) {
		setTitle("Upute");
		textArea.setText("Polja označena zvjezdicom su opcionalna, no ukoliko se ne odaberu sva potrebna opcionalna polja (za CBC način potreban je i inicijalizacijski vektor), algoritam će izraditi svoj ključ i inicijalizacijski vektor i spremiti ga u datoteku.");
	}
	else if (greska == 8) {
		setTitle("Upute");
		textArea.setText("Ukoliko dobivena dekriptirana datoteka nije tekstualna ili ima nečitljiv sadržaj to znači da odabrana kriptirana datoteka nije kriptirana odgovarajućim algoritmom.");
	}
	else if (greska == 9) {
		setTitle("Upute");
		textArea.setText("Tekst za dekriptiranje mora biti heksadekadski string.");
	}
	createEvents();
	}
	public void createEvents() {
		btnOk.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
	}
}
