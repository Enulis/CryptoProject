Aplikacija se pokre�e iz GROESTL Visual C# Project File. Upi�e se tekst za sa�imanje, izabere verzija i potom klikom na gumb POKRENI, pokre�e se ra�unanje sa�etka. U polju Rezultat se ispi�e dobivena poruka.

Groestl.zip je izvorna implementacija Groestl algoritma po kojem je ra�en ovaj projekt. 